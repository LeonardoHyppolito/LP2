﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace PContato0030482221027
{
    public partial class frmContato : Form
    {
        private BindingSource bnContato = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsContato = new DataSet();
        private DataSet dsCidade = new DataSet();
        public frmContato()
        {
            InitializeComponent();
        }

        private void FrmContato_Load(object sender, EventArgs e)
        {
            try
            {
                Contato Con = new Contato();
                dsContato.Tables.Add(Con.Listar());
                bnContato.DataSource = dsContato.Tables["Contato"];
                dgvContato.DataSource = bnContato;
                bnvContato.BindingSource = bnContato;


                txtIDContato.DataBindings.Add("TEXT", bnContato, "id_contato");
                txtNomeContato.DataBindings.Add("TEXT", bnContato, "nome_contato");
                txtEndContato.DataBindings.Add("TEXT", bnContato, "end_contato");
                txtCelContato.DataBindings.Add("TEXT", bnContato, "cel_contato");
                txtEmailContato.DataBindings.Add("TEXT", bnContato, "email_contato");
                dtpDtCadastroContato.DataBindings.Add("TEXT", bnContato, "dtcadastro_contato");

                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());
                cbxContato.DataSource = dsCidade.Tables["Cidade"];

                cbxContato.DisplayMember = "nome_cidade";

                cbxContato.ValueMember = "id_cidade";

                cbxContato.DataBindings.Add("SelectedValue", bnContato, "Cidade_id_Cidade");

            }

            catch (Exception)
            {
                MessageBox.Show("Erro ao listar Contatos");
            }
        }

        private void BtnNovo_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
            {
                tabControl1.SelectTab(1);
            }
            bnContato.AddNew();
            txtNomeContato.Enabled = true;
            cbxContato.Enabled = true;
            cbxContato.SelectedIndex = 1;
            txtNomeContato.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;

            txtCelContato.Enabled = true;
            txtEmailContato.Enabled = true;
            txtEndContato.Enabled = true;
            dtpDtCadastroContato.Enabled = true;
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
           
            Contato RegCid = new Contato();
            RegCid.Idcontato = Convert.ToInt32(txtIDContato.Text);
            RegCid.Nomecontato = txtNomeContato.Text;
            RegCid.Dtcadastrocontato = dtpDtCadastroContato.Value;
            RegCid.Endcontato = txtEndContato.Text;
            RegCid.Cidadeidcidade = Convert.ToInt32(cbxContato.SelectedValue);
            RegCid.Celcontato = txtCelContato.Text;
            RegCid.Emailcontato = txtEmailContato.Text;


            Boolean valid = ValidateInputs(RegCid.Nomecontato, RegCid.Endcontato, RegCid.Celcontato, RegCid.Emailcontato);

            if (valid) { 
                if (bInclusao)
                {
                    if (RegCid.Salvar() > 0)
                    {
                        MessageBox.Show("Contato adicionada com sucesso!", "SUCESSO");

                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCid.Listar());
                        txtIDContato.Enabled = false;
                        txtNomeContato.Enabled = false;
                        dtpDtCadastroContato.Enabled = false;
                        dtpDtCadastroContato.Enabled = false;

                        tabControl1.SelectTab(0);

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = true;
                        dtpDtCadastroContato.Enabled = true;

                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCid.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Contato!", "ERRO");
                    }
                }
                else
                {
                    if (RegCid.Alterar() > 0)
                    {
                        MessageBox.Show("Contato alterada com sucesso!");

                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCid.Listar());
                        txtIDContato.Enabled = false;
                        txtNomeContato.Enabled = false;
                        dtpDtCadastroContato.Enabled = false;

                        tabControl1.SelectTab(0);

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = true;
                        dtpDtCadastroContato.Enabled = true;

                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Contato!");
                    }
                }
            }

        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            bnContato.CancelEdit();
            tabControl1.SelectTab(0);

            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

            txtIDContato.Enabled = false;
            txtNomeContato.Enabled = false;
            dtpDtCadastroContato.Enabled = false;
        }

        static bool ValidateInputs(string nome, string endereco, string telefone, string email)
        {
            if (string.IsNullOrWhiteSpace(nome) || nome.Length < 2)
            {
                MessageBox.Show("Nome invalido");
                return false;
            }else if (string.IsNullOrWhiteSpace(endereco))
            {
                MessageBox.Show("Endereço invalido");
                return false;
            }else if (!Regex.IsMatch(telefone, @"^\d+$"))
            {
                MessageBox.Show("Telefone invalido");
                return false;
            }else if (!Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Email invalido");
                return false;
            }

            return true;
        }

        private void BtnExcluir_Click(object sender, EventArgs e)
        {
            if(tabControl1.SelectedIndex == 0)
            {
                tabControl1.SelectTab(1);
            }
            if(txtIDContato.Text != null)
            {
                dtpDtCadastroContato.Enabled = false;
                txtIDContato.Enabled = false;
                txtNomeContato.Enabled = false;
                txtEndContato.Enabled = false;
                cbxContato.Enabled = false;
                txtCelContato.Enabled = false;
                txtEmailContato.Enabled = false;

                btnSalvar.Enabled = false;
                btnAlterar.Enabled = true;
                btnNovo.Enabled = true;
                btnExcluir.Enabled = true;
                btnCancelar.Enabled = true;
                dtpDtCadastroContato.Enabled = false;

                if(MessageBox.Show("Confirmar exclusão?","Sim ou não", 
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button2) == DialogResult.Yes
                ){
                    Contato RegCon = new Contato();
                    RegCon.Idcontato = Convert.ToInt32(txtIDContato.Text);

                    if (RegCon.Excluir() > 0)
                    {
                        MessageBox.Show("Contato excluído com sucesso!");
                        Contato R = new Contato();
                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(R.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];

                        tabControl1.SelectTab(0);

                    }
                    else
                    {
                        MessageBox.Show("Error ao excluir contato!");
                    }
                }
                else
                {
                    tabControl1.SelectTab(0);
                }
            }
        }

        private void BtnAlterar_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
            {
                tabControl1.SelectTab(1);
            }

            Contato RegCid = new Contato();
            RegCid.Idcontato = Convert.ToInt32(txtIDContato.Text);
            RegCid.Nomecontato = txtNomeContato.Text;
            RegCid.Dtcadastrocontato = dtpDtCadastroContato.Value;
            RegCid.Endcontato = txtEndContato.Text;
            RegCid.Cidadeidcidade = Convert.ToInt32(cbxContato.SelectedValue);
            RegCid.Celcontato = txtCelContato.Text;
            RegCid.Emailcontato = txtEmailContato.Text;

            dtpDtCadastroContato.Enabled = true;
            txtIDContato.Enabled = true;
            txtNomeContato.Enabled = true;
            txtEndContato.Enabled = true;
            cbxContato.Enabled = true;
            txtCelContato.Enabled = true;
            txtEmailContato.Enabled = true;

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;


        }

        private void DgvContato_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

