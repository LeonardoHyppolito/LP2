﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //declarando variaveis globais, porque vão ser usadas em mais de um lugar.
        public Form1()
        {
            InitializeComponent();
        }

        private void Botao_limpar_Click(object sender, EventArgs e)
        {
            textoNum1.Clear();
            textoNum2.Clear();
            textoResultado.Clear();  // .Clear limpa a caixa de texto que antecede a ela no código; 
        }

        private void TxtNum2_Validated(object sender, EventArgs e) // Validando a caixa de texto 2 com _Validated.
        {
            if (!double.TryParse(textoNum2.Text, out numero2)) // Aqui fiquei com dificuldade de entender o TryParse,
                // mas basicamente, o TryParse é um bool, que retorna true quando a conversão de string para double 
                // funciona. Logo, o ponto de exclamação (!) antes do double indica para o comando if, que ele vai executar
                //o bloco de código abaixo caso o valor bool do TryParse seja False. Isso que me confundiu bastante
                //Em suma, neste trecho do código estamos pedindo pro Try parse conferir se a conversão funcionou
                // e caso não funcione (digitando letras por exemplo), o if executa o bloco, chamando a MessageBox.Show
                // com a mensagem que desejamos, neste caso "Numero 2 Inválido. 




            {
                MessageBox.Show("Número 2 inválido!"); //txtNum1.Focus();
            }
        }

        private void TxtNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Botao_soma_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(textoNum1.Text, out numero1)) && (double.TryParse(textoNum2.Text, out numero2)))
                //Lembrar que o TryParse confere se a conversão foi bem sucedida, e se sim o dado de retorno da 
                // conversão sai para a variável que fica depois do out. 
            {
                resultado = numero1 + numero2;
                textoResultado.Text = resultado.ToString(); // Após a conta, precisamos fazer com que o garoto double
                //volte a ser uma string e isso é simples: .ToString();
            }
            else MessageBox.Show("Números inválidos!");
        }

        private void Botao_sub_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(textoNum1.Text, out numero1)) && (double.TryParse(textoNum2.Text, out numero2)))
                // Lembrar que este .Text, é para pegar o texto dentro do campo textoNum1
            {
                resultado = numero1 - numero2;
                textoResultado.Text = resultado.ToString(); // Mesmo Código da soma, qualquer duvida estudar a documentação
                // do botão soma. 
            }
            else MessageBox.Show("Números inválidos!");
        }

        private void Botao_mult_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(textoNum1.Text, out numero1)) && (double.TryParse(textoNum2.Text, out numero2)))
            // Novamente a ideia é a mesma, o TryParse confere se a conversão foi bem feita, se sim : retorna o valor
            // convertido para a variável após o "out", se tudo certo : realiza a operação ( neste caso a de Multiplicar)
            //Após isso, armazena-se o valor da operação na variável resultado, e por fim pedimos para que o valor contido
            // na variável resultado seja o valor mostrad na caixa de texto resultado, sempre lembrando de retransformar
            // o double em uma string. 
            {
                resultado = numero1 * numero2;
                textoResultado.Text = resultado.ToString();
            }
            else MessageBox.Show("Números inválidos!");
        }

        private void Botao_div_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(textoNum1.Text, out numero1)) && (double.TryParse(textoNum2.Text, out numero2)))
            {
                if (numero2 == 0)
                    MessageBox.Show("Não pode dividir número por zero!");
                else
                    resultado = numero1 / numero2;
                textoResultado.Text = resultado.ToString();
            }
            else MessageBox.Show("Números inválidos!");
            // a unica diferença da divisão para outras operações, é que temos que lembrar que temos uma condição 
            // universal, que é a de não permitir que seja feita uma divisão por zero. Porém aqui me confundi, nas sequencias 
            // dos "IF´s", a condicional de não dividir por zero tem que estar dentro da condicional do TryParse. 
        }

        private void txtNum1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtResult_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Botao_sair_Click_1(object sender, EventArgs e)
        {
            Close();  // Para sair, é bem parecido com o limpar, só claro, muda o nome .Close() para fechar. 
        }


        private void TxtNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textoNum1.Text, out numero1))
            {
                MessageBox.Show("Número 1 inválido!"); //textoNum1.Focus();
            }
        }
    }
}
