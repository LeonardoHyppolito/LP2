﻿namespace PCalc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textoNum1 = new System.Windows.Forms.TextBox();
            this.textoNum2 = new System.Windows.Forms.TextBox();
            this.textoResultado = new System.Windows.Forms.TextBox();
            this.botao_soma = new System.Windows.Forms.Button();
            this.botao_limpa = new System.Windows.Forms.Button();
            this.botao_subtrai = new System.Windows.Forms.Button();
            this.botao_multiplica = new System.Windows.Forms.Button();
            this.botao_dividir = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.botao_sair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textoNum1
            // 
            this.textoNum1.Location = new System.Drawing.Point(655, 47);
            this.textoNum1.Margin = new System.Windows.Forms.Padding(4);
            this.textoNum1.Name = "textoNum1";
            this.textoNum1.Size = new System.Drawing.Size(132, 20);
            this.textoNum1.TabIndex = 13;
            this.textoNum1.TextChanged += new System.EventHandler(this.txtNum1_TextChanged);
            this.textoNum1.Validated += new System.EventHandler(this.TxtNum1_Validated);
            // 
            // textoNum2
            // 
            this.textoNum2.Location = new System.Drawing.Point(655, 106);
            this.textoNum2.Margin = new System.Windows.Forms.Padding(4);
            this.textoNum2.Name = "textoNum2";
            this.textoNum2.Size = new System.Drawing.Size(132, 20);
            this.textoNum2.TabIndex = 14;
            this.textoNum2.TextChanged += new System.EventHandler(this.TxtNum2_TextChanged);
            this.textoNum2.Validated += new System.EventHandler(this.TxtNum2_Validated);
            // 
            // textoResultado
            // 
            this.textoResultado.Enabled = false;
            this.textoResultado.Location = new System.Drawing.Point(655, 181);
            this.textoResultado.Margin = new System.Windows.Forms.Padding(4);
            this.textoResultado.Name = "textoResultado";
            this.textoResultado.Size = new System.Drawing.Size(132, 20);
            this.textoResultado.TabIndex = 15;
            this.textoResultado.TextChanged += new System.EventHandler(this.txtResult_TextChanged);
            // 
            // botao_soma
            // 
            this.botao_soma.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.botao_soma.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.botao_soma.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.botao_soma.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botao_soma.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.botao_soma.Location = new System.Drawing.Point(550, 220);
            this.botao_soma.Name = "botao_soma";
            this.botao_soma.Size = new System.Drawing.Size(47, 47);
            this.botao_soma.TabIndex = 16;
            this.botao_soma.Text = "+";
            this.botao_soma.UseVisualStyleBackColor = false;
            this.botao_soma.Click += new System.EventHandler(this.Botao_soma_Click);
            // 
            // botao_limpa
            // 
            this.botao_limpa.BackColor = System.Drawing.SystemColors.ControlDark;
            this.botao_limpa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botao_limpa.Location = new System.Drawing.Point(546, 9);
            this.botao_limpa.Name = "botao_limpa";
            this.botao_limpa.Size = new System.Drawing.Size(111, 30);
            this.botao_limpa.TabIndex = 20;
            this.botao_limpa.Text = "Limpar";
            this.botao_limpa.UseVisualStyleBackColor = false;
            this.botao_limpa.Click += new System.EventHandler(this.Botao_limpar_Click);
            // 
            // botao_subtrai
            // 
            this.botao_subtrai.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.botao_subtrai.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botao_subtrai.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.botao_subtrai.Location = new System.Drawing.Point(614, 220);
            this.botao_subtrai.Name = "botao_subtrai";
            this.botao_subtrai.Size = new System.Drawing.Size(47, 47);
            this.botao_subtrai.TabIndex = 22;
            this.botao_subtrai.TabStop = false;
            this.botao_subtrai.Text = "-";
            this.botao_subtrai.UseVisualStyleBackColor = false;
            this.botao_subtrai.Click += new System.EventHandler(this.Botao_sub_Click);
            // 
            // botao_multiplica
            // 
            this.botao_multiplica.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.botao_multiplica.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botao_multiplica.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.botao_multiplica.Location = new System.Drawing.Point(688, 220);
            this.botao_multiplica.Name = "botao_multiplica";
            this.botao_multiplica.Size = new System.Drawing.Size(47, 47);
            this.botao_multiplica.TabIndex = 23;
            this.botao_multiplica.Text = "*";
            this.botao_multiplica.UseVisualStyleBackColor = false;
            this.botao_multiplica.Click += new System.EventHandler(this.Botao_mult_Click);
            // 
            // botao_dividir
            // 
            this.botao_dividir.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.botao_dividir.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botao_dividir.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.botao_dividir.Location = new System.Drawing.Point(753, 220);
            this.botao_dividir.Name = "botao_dividir";
            this.botao_dividir.Size = new System.Drawing.Size(47, 47);
            this.botao_dividir.TabIndex = 24;
            this.botao_dividir.Text = "/";
            this.botao_dividir.UseVisualStyleBackColor = false;
            this.botao_dividir.Click += new System.EventHandler(this.Botao_div_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(546, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 26);
            this.label1.TabIndex = 25;
            this.label1.Text = "Número 1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(546, 102);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 26);
            this.label2.TabIndex = 26;
            this.label2.Text = "Número 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(546, 176);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 26);
            this.label3.TabIndex = 27;
            this.label3.Text = "Resultado";
            // 
            // botao_sair
            // 
            this.botao_sair.BackColor = System.Drawing.SystemColors.ControlDark;
            this.botao_sair.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botao_sair.Location = new System.Drawing.Point(676, 9);
            this.botao_sair.Name = "botao_sair";
            this.botao_sair.Size = new System.Drawing.Size(111, 30);
            this.botao_sair.TabIndex = 28;
            this.botao_sair.Text = "Sair";
            this.botao_sair.UseVisualStyleBackColor = false;
            this.botao_sair.Click += new System.EventHandler(this.Botao_sair_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.botao_sair);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.botao_dividir);
            this.Controls.Add(this.botao_multiplica);
            this.Controls.Add(this.botao_subtrai);
            this.Controls.Add(this.botao_limpa);
            this.Controls.Add(this.botao_soma);
            this.Controls.Add(this.textoResultado);
            this.Controls.Add(this.textoNum2);
            this.Controls.Add(this.textoNum1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textoNum1;
        private System.Windows.Forms.TextBox textoNum2;
        private System.Windows.Forms.TextBox textoResultado;
        private System.Windows.Forms.Button botao_soma;
        private System.Windows.Forms.Button botao_limpa;
        private System.Windows.Forms.Button botao_subtrai;
        private System.Windows.Forms.Button botao_multiplica;
        private System.Windows.Forms.Button botao_dividir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button botao_sair;
    }
}

